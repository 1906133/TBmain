class Task {
  String title;
  bool complete;

  Task(this.title, this.complete);
}
