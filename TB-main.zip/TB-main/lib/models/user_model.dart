class User {
  String username;

  User(this.username);
}
